<?php
session_start();

header("Location: rules.html");
exit();
?>
